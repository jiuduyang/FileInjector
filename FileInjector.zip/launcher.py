import os
import subprocess
import sys

def main():
    # 检查Java是否安装
    try:
        subprocess.run(['java', '-version'], capture_output=True, check=True)
    except (subprocess.SubprocessError, FileNotFoundError):
        # 使用Windows消息框显示错误信息
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "未找到Java环境，请先安装Java 8或更高版本！\n\n下载地址：https://www.oracle.com/java/technologies/downloads/", "错误", 0)
        return

    # 编译Java文件
    compile_result = subprocess.run(['javac', 'FileInjector.java'], capture_output=True, text=True)
    if compile_result.returncode != 0:
        # 使用Windows消息框显示错误信息
        import ctypes
        error_message = "编译失败：\n\n" + compile_result.stderr
        ctypes.windll.user32.MessageBoxW(0, error_message, "错误", 0)
        return

    # 运行Java程序
    subprocess.run(['java', 'FileInjector'])

if __name__ == "__main__":
    main()