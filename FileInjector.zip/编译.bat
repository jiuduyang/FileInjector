@echo off
chcp 65001

:: 编译和运行脚本
:: 编译Java文件并运行程序

echo 正在编译文件随机注入隐藏工具...

:: 编译Java文件
javac FileInjector.java

:: 检查编译是否成功
if exist "FileInjector.class" (
    echo 编译成功！
    echo 正在运行程序...
    echo.
    java FileInjector
) else (
    echo 编译失败！请检查Java环境是否正确安装。
    echo 下载地址：https://www.oracle.com/java/technologies/downloads/
    pause
    exit /b 1
)