@echo off
chcp 65001

:: 使用Python打包脚本
:: 将Python启动器打包成exe可执行文件

echo ===============================================
echo 文件随机注入隐藏工具 - Python打包脚本
echo ===============================================

echo 1. 检查Python是否安装...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误：未找到Python环境，请先安装Python！
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

echo 2. 检查pyinstaller是否安装...
pip show pyinstaller >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在安装pyinstaller...
    pip install pyinstaller
    if %errorlevel% neq 0 (
        echo 安装pyinstaller失败！
        pause
        exit /b 1
    )
)

echo 3. 正在打包成exe可执行文件...
pyinstaller --onefile --windowed --name FileInjector launcher.py

if exist "dist\FileInjector.exe" (
    echo ===============================================
    echo 打包成功！
    echo 可执行文件：dist\FileInjector.exe
    echo.
    echo 提示：运行FileInjector.exe需要Java 8或更高版本
    echo ===============================================
    pause
) else (
    echo 打包失败！请检查错误信息。
    pause
    exit /b 1
)